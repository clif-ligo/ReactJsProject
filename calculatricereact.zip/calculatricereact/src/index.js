import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import './index.css';

class BoutonCalc extends React.Component {
    render() {
        return (
            <button
                onClick={this.props.onClick}>
            </button>
        )
    }

}

class EcranCalc extends React.Component {
    render() {
        return (
            <div class = "ecran">

                {this.props.valueToDisplay}
            </div>

        )
    }
}

class EcranHistorique extends React.Component {
    render() {
        return (
            <div>
                {this.props.valueToDisplay}
            </div>

        )
    }
}



class Calculatrice extends React.Component {
    constructor(props){
        super(props);
        this.state = {
            premiereVal:"",
            deuxiemeVal:"",
            operateur: "",
            valueToDisplay:"",
            historique:[],
            showHistorique:true
        };

    }
    clear(){
        this.setState({
            premiereVal:"",
            deuxiemeVal:"",
            operateur: "",
            valueToDisplay:"",
        })
    }
    ajouteValue(val){
        if ((this.state.operateur === "" )&&(this.state.premiereVal.length<10)){
            this.setState({premiereVal :this.state.premiereVal + val, valueToDisplay: this.state.premiereVal + val})
        }
        if ((this.state.operateur !== "" )&&(this.state.deuxiemeVal.length<10)){
            this.setState({deuxiemeVal :this.state.deuxiemeVal + val, valueToDisplay: this.state.deuxiemeVal + val})
        }
    }


    ajouteOperation(ope){
        if (this.state.operateur !== ""){
            this.setState({operateur: ope, premiereVal: this.state.valueToDisplay, deuxiemeVal: ""});
        }
        else {
            this.setState({operateur :ope})
        }
    }

    calcul (){
        switch (this.state.operateur){
            case "+" :
                this.setState({valueToDisplay: parseFloat(this.state.premiereVal) + parseFloat(this.state.deuxiemeVal)});
                break;
            case "-" :
                this.setState({valueToDisplay: parseFloat(this.state.premiereVal) - parseFloat(this.state.deuxiemeVal)});
                break;

            case "/" :
                this.setState({valueToDisplay: parseFloat(this.state.premiereVal) / parseFloat(this.state.deuxiemeVal)});
                break;

            case "*" :
                this.setState({valueToDisplay: parseFloat(this.state.premiereVal) * parseFloat(this.state.deuxiemeVal)});
                break;

            default:
                this.setState({valueToDisplay: "erreur"});
                break;
        }
        this.setState({historique: this.state.historique.concat("["+ this.state.premiereVal, this.state.operateur, this.state.deuxiemeVal + "], ")});

    }

    render() {
        console.log("premiere val : " + this.state.premiereVal);
        console.log("operateur : " + this.state.operateur);
        console.log("deuxieme val : " + this.state.deuxiemeVal);
        console.log("val to display val : " + this.state.valueToDisplay);
        console.log("stop");

        return (
            <div>
                <table>
                    <tr className="ecran">
                        <td colSpan="4">
                            <EcranCalc valueToDisplay={this.state.valueToDisplay}/>
                        </td>
                    </tr>


                    <tr>
                        <td>
                            <button className = "buttonChiffre"  onClick={() => this.ajouteValue("1")}>1</button>
                        </td>

                        <td>
                            <button className = "buttonChiffre"  onClick={() => this.ajouteValue("2")}>2</button>
                        </td>

                        <td>
                            <button className = "buttonChiffre"  onClick={() => this.ajouteValue("3")}>3</button>

                        </td>
                        <td>
                            <button className = "buttonOperator" onClick={() => this.ajouteOperation("+")}>+</button>
                        </td>
                    </tr>


                    <tr>
                        <td>
                            <button className = "buttonChiffre"  onClick={() => this.ajouteValue("4")}>4</button>
                        </td>

                        <td>
                            <button className = "buttonChiffre"  onClick={() => this.ajouteValue("5")}>5</button>
                        </td>

                        <td>
                            <button className = "buttonChiffre"  onClick={() => this.ajouteValue("6")}>6</button>
                        </td>
                        <td>
                            <button className = "buttonOperator" onClick={() => this.ajouteOperation("-")}>-</button>
                        </td>
                    </tr>

                    <tr>

                        <td>
                            <button className = "buttonChiffre"  onClick={() => this.ajouteValue("7")}>7</button>
                        </td>

                        <td>
                            <button className = "buttonChiffre"  onClick={() => this.ajouteValue("8")}>8</button>
                        </td>

                        <td>
                            <button className = "buttonChiffre"  onClick={() => this.ajouteValue("9")}>9</button>
                        </td>

                        <td>
                            <button className = "buttonOperator" onClick={() => this.ajouteValue("*")}>*</button>
                        </td>
                    </tr>

                    <tr>
                        <td>
                            <button className = "buttonChiffre"  onClick={() => this.ajouteValue("0")}>0</button>
                        </td>
                        <td>
                            <button className = "buttonChiffre"  onClick={() => this.ajouteValue(".")}>.</button>
                        </td>

                        <td>
                            <button className = "buttonChiffre" onClick={() => this.clear()}>C</button>
                            <br/>
                        </td>

                        <td>
                            <button className = "buttonOperator" onClick={() => this.ajouteOperation("/")}>/</button>
                            <br/>
                        </td>

                    </tr>
                    <tr>
                        <td colSpan="4">
                            <button className = "buttonChiffre" onClick={() => this.calcul()}>=</button>
                        </td>
                    </tr>

                </table>

                <table className="tableHistorique">
                    <tr>
                        <td>
                            <button className="historique" onClick={()=>this.setState({showHistorique : !this.state.showHistorique})} >Historique</button>
                            {this.state.showHistorique ?  <EcranHistorique valueToDisplay = {this.state.historique} /> : null}

                        </td>
                    </tr></table>











            </div>


        )
    }

}

ReactDOM.render(<Calculatrice/>, document.getElementById('root'));



